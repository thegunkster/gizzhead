//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#if !defined( DMC_TELEPORTERS_H )
#define DMC_TELEPORTERS_H
#ifdef _WIN32
#pragma once
#endif

void Dmc_CheckTeleporters( struct local_state_s *from, struct local_state_s *to );

#endif // DMC_TELEPORTERS_H