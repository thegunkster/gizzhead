//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

// Physics info string definition
#if !defined( PM_INFOH )
#define PM_INFOH
#pragma once

#define MAX_PHYSINFO_STRING 256

#endif // PM_INFOH